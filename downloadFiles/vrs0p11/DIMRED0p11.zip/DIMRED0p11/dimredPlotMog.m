function model = dimredPlotMog(numComponents, numPoints)

% DIMREDPLOTMOG Plot a mixture of Gaussians plus data.
%
%	Description:
%
%	MODEL = DIMREDPLOTMOG(NUMCOMPONENTS, NUMDATA) plots a mixture of
%	Gaussians plus data sampled from it.
%	 Returns:
%	  MODEL - the model that was created.
%	 Arguments:
%	  NUMCOMPONENTS - number of components in the mixture.
%	  NUMDATA - the number of data to sample.
%	
%
%	See also
%	ICMLFIGURES


%	Copyright (c) 2008 Neil D. Lawrence
% 	dimredPlotMog.m SVN version 20
% 	last update 2008-06-25T17:26:35.000000Z
  
% Sample some data from a mixture of Gaussians.

options = mogOptions(numComponents);
model = mogCreate(1, 2, randn(numComponents*3, 2), options);

for i = 1:model.m
  model.W{i} = randn(size(model.W{i}))*0.1;
  model.sigma2(i) = rand(1)*0.01;
  model.U{i} = sqrt(model.sigma2(i))*eye(model.d);
  for j = 1:model.q
    model.U{i} = cholupdate(model.U{i}, model.W{i}(:, j));
  end
end

model.Y = mogSample(model, numPoints);
mogTwoDPlot(model);

