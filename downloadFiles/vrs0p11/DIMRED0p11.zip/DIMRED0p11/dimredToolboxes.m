
% DIMREDTOOLBOXES Toolboxes required for the dimensional reduction demos.
%
%	Description:
%	% 	dimredToolboxes.m CVS version 1.1
% 	dimredToolboxes.m SVN version 26
% 	last update 2008-07-11T21:31:54.000000Z
importLatest('netlab');
importLatest('ndlutil');
importLatest('kern');
importLatest('optimi');
importLatest('mocap');
importLatest('fgplvm');
importLatest('gp');
importLatest('datasets');
importLatest('mltools');
importLatest('plot2svg');
importLatest('rotate_image');
importLatest('m_map');
importLatest('isomap');
importLatest('lle');
