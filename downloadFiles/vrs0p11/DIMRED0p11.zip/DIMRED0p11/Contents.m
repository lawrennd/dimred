% DIMRED toolbox
% Version 0.11		12-Jul-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% DEMISOMAP Try isomap on the toy data sets.
% DEMDIGITSMANIFOLD Project and rotate an artificial data set of handwritten digits. 
% DEMSTICKDNET2 Model the stick man using an GTM -- 20x20 grid.
% DEMROTATIONDIST Small movie of rotation required to improve variance retention.
% DEMOILDNET5 Oil data using DNET with 400 points.
% DIMREDPLOTMOG Plot a mixture of Gaussians plus data.
% DEMCMDSSIXES Do classical scaling on the six data.
% DEMSIXMOG1 Demonstrate mixture of Gaussians sixes.
% DEMSTICKMOG1 Demonstrate mixture of Gaussians on stick man.
% DEMMANIFOLD Show rotation of the digit 6/9.
% DEMCMDSROADDATA This script uses classical MDS to visualise some road distance data.
% DIMREDPREPPLOT Dimensional reduction plot preparation.
% DEMSTICKGTM2 Model the stick man using an GTM -- 20x20 grid.
% DEMMANIFOLDPRINT Print the principal components of the artificial digits data set.
% DEMSTICKPPCA1 Model the stick man using Probabilistic PCA
% DEMICMLTALK Show demos for ICML talk in order.
% DEMSIXKPCA Plot Kernel PCA associated with the rotated six data.
% DEMSTICKDNET4 Model the stick man using an GTM -- 60x60 grid.
% DEMSTICKDNET3 Model the stick man using an GTM -- 30x30 grid.
% ICMLFIGURES Plot some of the figures used in ICML tutorial.
% DEMOILDNET2 Oil data using GTM with 20x20 grid.
% DEMOILFGPLVM1 Oil data using FGPLVM with fully independent training conditional.
% DEMSIXDISTANCES Plot distance matrix associated with the rotated six data.
% DEMOILDNET4 Oil data using DNET with 100 points.
% GENERATEMANIFOLDDATA Generates simple toy data sets for analyzing.
% DEMOILDNET3 Oil data using GTM with 30x30 grid.
% DEMSTICKDNET1 Model the stick man using an GTM 10x10 grid.
% DIMREDTOOLBOXES Toolboxes required for the dimensional reduction demos.
% DEMSTICKGTM3 Model the stick man using an GTM -- 40x40 grid.
% DEMOILDNET1 Oil data using GTM with 10x10 grid.
% DEMOILPPCA1 Oil data using PPCA.
% DEMLLE Try LLE on the toy data sets.
% DEMSTICKGTM4 Model the stick man using an GTM -- 60x60 grid.
