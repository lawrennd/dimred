
% DIMREDTOOLBOXES Toolboxes required for the dimensional reduction demos.
%
%	Description:
%	% 	dimredToolboxes.m version 1.1

importLatest('netlab');
importLatest('ndlutil');
importLatest('kern');
importLatest('optimi');
importLatest('mocap');
importLatest('datasets');
importLatest('mltools');
importLatest('rotate_image');
importLatest('m_map');
importLatest('isomap');
importLatest('lle');
