
% DEMISOMAP Try isomap on the toy data sets.
%
%	Description:
%	% 	demIsomap.m CVS version 1.1
% 	demIsomap.m SVN version 20
% 	last update 2008-01-23T00:04:30.000000Z
% COPYRIGHT : Neil D. Lawrence, 2008


options.numData = 1000;
options.display = 1;

for dataType = {'plane', 'swissroll', 'trefoil'}
  [Y, colourmap] = generateManifoldData(dataType{1}, options);
  X = isomapEmbed(Y, 2); 
  figure, 
  scatter(X(:, 1), X(:, 2), 50, colourmap, 'filled') 
  capData = dataType{1};
  capData(1) = upper(capData(1));
  dimredPrepPlot(gca, ['demIsomap' capData]);
end
