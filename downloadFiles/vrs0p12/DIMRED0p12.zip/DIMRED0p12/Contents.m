% DIMRED toolbox
% Version 0.12		06-Sep-2009
% Copyright (c) 2009, Neil D. Lawrence
% 
, Neil D. Lawrence
% DEMSTICKMANIFOLD Project the stick man linearly.
% DEMCRABPPCA1 Crab data using PPCA.
% DEMISOMAP Try isomap on the toy data sets.
% DEMGRID_VOWELSFGPLVM1 Grid vowels data using GPLVM.
% DEMDIGITSMANIFOLD Project and rotate an artificial data set of handwritten digits. 
% DEMSTICKDNET2 Model the stick man using an GTM -- 20x20 grid.
% DEMCRABSGTM1 Crabs data using GTM with 10x10 grid.
% DEMROTATIONDIST Small movie of rotation required to improve variance retention.
% DEMGRID_VOWELSISOMAP1 Model the Grid vowels data using isomap with 7 neighbors.
% DEMGRID_VOWELSLE1 Model the Grid vowels data using LE with 7 neighbors.
% DEMOILLLE1 Model the oil data using LLE with 7 neighbors.
% DEMOILDNET5 Oil data using DNET with 400 points.
% DIMREDPLOTSQUAREDDISTANCES Helper function for plotting interpoint distances.
% DIMREDPLOTMOG Plot a mixture of Gaussians plus data.
% DEMCRABSGTM2 Crabs data using GTM with 20x20 grid.
% DEMCMDSSIXES Do classical scaling on the six data.
% DEMSIXMOG1 Demonstrate mixture of Gaussians sixes.
% DEMSTICKMOG1 Demonstrate mixture of Gaussians on stick man.
% DEMMANIFOLD Show rotation of the digit 6/9.
% DEMINTERSPEECHTALK Show demos for Interspeech talk in order.
% DEMCMDSROADDATA This script uses classical MDS to visualise some road distance data.
% DIMREDPREPPLOT Dimensional reduction plot preparation.
% DEMSTICKGTM2 Model the stick man using an GTM -- 20x20 grid.
% DEMGRID_VOWELSPPCA1 Model the grid vowels man using Probabilistic PCA
% DEMOILISOMAP1 Model the oil data using isomap with 7 neighbors.
% DEMCMPFGPLVM1 Grid data MFCCs using FGPLVM.
% DEMMANIFOLDPRINT Print the principal components of the artificial digits data set.
% DEMSTICKPPCA1 Model the stick man using Probabilistic PCA
% DEMICMLTALK Show demos for ICML talk in order.
% DEMSIXKPCA Plot Kernel PCA associated with the rotated six data.
% DEMSTICKMANIFOLDPRINT Print the principal components of stick data set.
% DEMSTICKLE1 Model the stick man with LE using 7 neighbors.
% DEMSTICKDNET4 Model the stick man using an GTM -- 60x60 grid.
% DEMCMPFGPLVM2 Grid data MFCCs using FGPLVM.
% DEMSTICKDNET3 Model the stick man using an GTM -- 30x30 grid.
% ICMLFIGURES Plot some of the figures used in ICML tutorial.
% DEMOILDNET2 Oil data using GTM with 20x20 grid.
% DEMOILFGPLVM1 Oil data using FGPLVM with fully independent training conditional.
% DEMSIXDISTANCES Plot distance matrix associated with the rotated six data.
% DEMBACKMAPPING Show difference in latent variable models that use a forward and reverse mapping.
% DEMCMPPPCA1 Grid data MFCCs using PPCA.
% DEMSTICKMVU1 Model the stick man with MVU using 7 neighbors.
% DEMOILDNET4 Oil data using DNET with 100 points.
% DEMSTICKLLE1 Model the stick man with LLE using 7 neighbors.
% GENERATEMANIFOLDDATA Generates simple toy data sets for analyzing.
% DIMREDDIMENSIONMASS Plot changing proportions associated with the dimensions.
% DEMOILDNET3 Oil data using GTM with 30x30 grid.
% DEMSTICKDNET1 Model the stick man using an GTM 10x10 grid.
% DEMSTICKISOMAP1 Model the stick man with isomap using 7 neighbors.
% DEMGRID_VOWELSLLE1 Model the Grid vowels data using LLE with 7 neighbors.
% DIMREDTOOLBOXES Toolboxes required for the dimensional reduction demos.
% DEMDURPPCA1 Grid data durations using PPCA.
% DEMSTICKGTM3 Model the stick man using an GTM -- 40x40 grid.
% DEMOILDNET1 Oil data using GTM with 10x10 grid.
% DEMOILPPCA1 Oil data using PPCA.
% DIMREDFIGURES Plot some of the figures used in the Book.
% DEMLLE Try LLE on the toy data sets.
% DEMSTICKGTM4 Model the stick man using an GTM -- 60x60 grid.
