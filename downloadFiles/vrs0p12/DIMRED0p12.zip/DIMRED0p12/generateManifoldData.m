function [Y, colourmap] = generateManifoldData(dataType, options)

% GENERATEMANIFOLDDATA Generates simple toy data sets for analyzing.
%
%	Description:
%
%	[Y, COLOURMAP] = GENERATEMANIFOLDDATA(DATATYPE) generates simple
%	data sets for exploring dimensional reduction algorithms.
%	 Returns:
%	  Y - the generated data set.
%	  COLOURMAP - colormap values for assisting in visualisation.
%	 Arguments:
%	  DATATYPE - the data set to generate. Can be one of 'six',
%	   'sixnine', 'swissroll', 'swissroll_small', 'trefoil', 'plane'
%	DESC generates simple data sets for exploring dimensional reduction
%	algorithms.
%	ARG dataType : the data set to generate. Can be one of 'six',
%	'sixnine', 'swissroll',
%	'swissroll_small', 'trefoil', 'plane'
%	ARG option : additional option structure with fields 'noiseType',
%	'noiseAmplitude', 'display'.
%	RETURN y : the generated data set.
%	RETURN colourmap : colormap values for assisting in visualisation.
%	
%	


%	Copyright (c) 2007 Carl Henrik Ek
%	Copyright (c) 2008 Neil D. Lawrence
% 	generateManifoldData.m CVS version 1.2
% 	generateManifoldData.m SVN version 20
% 	last update 2008-01-23T00:51:32.000000Z
  
if nargin < 2
  options.display = false;
  options.noiseAmplitude = 0.4;
  options.numData = 1600;
  options.seed = 1e6;
end
if ~isfield(options, 'display') || isempty(options.display)
  options.display = false;
end
if ~isfield(options, 'noiseAmplitude') || isempty(options.noiseAmplitude)
  options.noiseAmplitude = 0.4;
end
if ~isfield(options, 'numData') || isempty(options.numData)
  options.numData = 1600;
end
if ~isfield(options, 'seed') || isempty(options.seed)
  options.seed = 1e6;
end

% Make data generation repeatable.
randn('seed', options.seed);
rand('seed', options.seed);

switch dataType
 case 'swissroll'
  t = 3*(pi/2)*(1+2*rand(1,options.numData));
  Y(:,1) = t.*cos(t);
  Y(:,2) = 3*7*rand(1,options.numData);
  Y(:,3) = t.*sin(t);
  colourmap = t;
 case 'swissroll_small'
  t = 3*(pi/4)*(1+2*rand(1,options.numData));
  Y(:,1) = t.*cos(t);
  Y(:,2) = 3*7*rand(1,options.numData);
  Y(:,3) = t.*sin(t);
  colourmap = t;
 case 'trefoil'
  t = 0:2*pi/options.numData:2*pi-2*pi/options.numData;
  Y(:,1) = -10*cos(t)-2*cos(5.*t)+15*sin(2.*t);
  Y(:,2) = -15*cos(2*t)+10*sin(t)-2*sin(5*t);
  Y(:,3) = 10*cos(3*t);
  Y = Y/1.5;
  colourmap = t;
 case 'plane'
  [x y] = meshgrid(linspace(-5,5,ceil(sqrt(options.numData))),linspace(-5,5,ceil(sqrt(options.numData))));
  z = 1/2.*(x+y);
  Y(:,1) = x(:);
  Y(:,2) = y(:);
  Y(:,3) = z(:);
  colourmap = Y(:,3);
  
 case 'six'
  sixImage = double(imread('br1561_6.3.pgm'));
  rows = size(sixImage, 1);
  sixImage = uint8(-sixImage+255);
  sixImage = [zeros(rows, 3) sixImage zeros(rows, 4)];
  dimOne = size(sixImage);
  
  angles = 0:1:359;
  i = 0;
  Y = zeros(length(angles), prod(dimOne));
  for i = 1:length(angles);
    angle = angles(i);
    [rotImage, void] = rotate_image(angle, double(sixImage), ones(4, 2));
    dimTwo = size(rotImage);
    start = round((dimTwo - dimOne)/2);
    cropImage = rotImage(start(1)+[1:dimOne(1)], start(2)+[1:dimOne(2)]);
    Y(i, :) = cropImage(:)';
  end 

 case 'sixnine'
  sixAngles = [260:359 0:35];
  nineAngles = 85:215; 
  sixImage = double(imread('br1561_6.3.pgm'));
  rows = size(sixImage, 1);
  sixImage = uint8(-sixImage+255);
  sixImage = [zeros(rows, 3) sixImage zeros(rows, 4)];
  dimOne = size(sixImage);
  
  angles = sort([sixAngles nineAngles]);
  i = 0;
  Y = zeros(length(angles), prod(dimOne));
  for i = 1:length(angles);
    angle = angles(i);
    [rotImage, void] = rotate_image(angle, double(sixImage), ones(4, 2));
    dimTwo = size(rotImage);
    start = round((dimTwo - dimOne)/2);
    cropImage = rotImage(start(1)+[1:dimOne(1)], start(2)+[1:dimOne(2)]);
    Y(i, :) = cropImage(:)';
  end 
  
 otherwise
  error('Unknown Type');
end

Y = Y + options.noiseAmplitude.*randn(size(Y));
    
% remove mean
Y = Y - repmat(mean(Y),size(Y,1),1);

if(options.display)
  colormap jet;
  handle = scatter3(Y(:,1),Y(:,2),Y(:,3),50,colourmap,'filled');
  set(handle,'MarkerEdgeColor',[0.5,0.5,0.5]);
  dimredPrepPlot(gca, [dataType 'Data']);
end
