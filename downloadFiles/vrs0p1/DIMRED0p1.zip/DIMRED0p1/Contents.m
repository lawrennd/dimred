% DIMRED toolbox
% Version 0.1		23-Jan-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% DEMDIGITSMANIFOLD Project and rotate an artificial data set of handwritten digits. 
% GENERATEMANIFOLDDATA Generates simple toy data sets for analyzing.
% DEMCMDSSIXES Do classical scaling on the six data.
% DEMISOMAP Try isomap on the toy data sets.
% DEMROTATIONDIST Small movie of rotation required to improve variance retention.
% DIMREDPREPPLOT Dimensional reduction plot preparation.
% DEMLLE Try LLE on the toy data sets.
% DEMMANIFOLDPRINT Print the principal components of the artificial digits data set.
% DIMREDTOOLBOXES Toolboxes required for the dimensional reduction demos.
% DEMSIXDISTANCES Plot distance matrix associated with the rotated six data.
% DEMSIXKPCA Plot Kernel PCA associated with the rotated six data.
% DEMCMDSROADDATA This script uses classical MDS to visualise some road distance data.
