
% DIMREDTOOLBOXES Toolboxes required for the dimensional reduction demos.
%
%	Description:
%	% 	dimredToolboxes.m CVS version 1.1
% 	dimredToolboxes.m SVN version 504
% 	last update 2009-09-05T21:55:04.000000Z
importLatest('netlab');
importLatest('ndlutil');
importLatest('kern');
importLatest('optimi');
importLatest('mocap');
importLatest('prior');
importLatest('fgplvm');
importLatest('gp');
importLatest('datasets');
importLatest('mltools');
importTool('synth');
importLatest('plot2svg');
importLatest('rotate_image');
importLatest('m_map');
importLatest('isomap');
importLatest('lle');
importLatest('mvu');
importLatest('sedumi');
importLatest('voicebox');