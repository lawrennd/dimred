function [epsFileName, pngFileName] = dimredPrepPlot(ax, name)

% DIMREDPREPPLOT Dimensional reduction plot preparation.
%
%	Description:
%
%	DIMREDPREPPLOT(AX, NAME) prepares a dimensional reduction toolbox
%	plot by formating axes etc.
%	 Arguments:
%	  AX - the axes to format.
%	  NAME - a string to be used.
%	
%
%	See also
%	GENERATEMANIFOLDDATA


%	Copyright (c) 2008 Neil D. Lawrence
% 	dimredPrepPlot.m CVS version 1.2
% 	dimredPrepPlot.m SVN version 20
% 	last update 2008-01-23T00:51:32.000000Z

set(ax, 'fontName', 'helvetica');
set(ax, 'fontsize', 18);

epsFileName = ['../tex/diagrams/' name '.eps'];
pngFileName = ['../html/' name '.png'];
